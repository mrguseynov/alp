<header>
    <div class="top-nav-bar">
        <div class="container">
            <div class="row">
                <div class="header-top-left col-sm-6">
                    World's Fastest Online Shopping Destination
                </div>
                <div class="header-top-right col-sm-6">

                   <div class="lang-menu">
                       <ul>
                           <li>
							   <a class="drop-toogle"><img src="<?php echo e(asset('flags/small/ge.svg')); ?>" alt=""> <span>Georgia</span></a>
                                <ul class="dropdown">
                                    <li><a href=""><img src="<?php echo e(asset('flags/small/en.svg')); ?>" alt="">English</a></li>
                                    <li><a href=""><img src="<?php echo e(asset('flags/small/tr.svg')); ?>" alt="">Turkish</a></li>
                                    <li><a href=""><img src="<?php echo e(asset('flags/small/ru.svg')); ?>" alt="">Rusian</a></li>
                                </ul>
                           </li>
                       </ul>
                   </div>
                </div>
            </div>

        </div>
    </div>
    <div class="header-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="logo">
                        <a href="/">
                            <img src="<?php echo e(asset('logo.svg')); ?>" alt="">
                        </a>
                    </div>
                </div>
                <div class="col-sm-5">
                    <div class="searchbar-info">
                        <span>Offer zone</span>
                        <span>Track order</span>
                        <span>Best Selling Items</span>
                    </div>
                    <div class="search-senction">
                        <form action="">
                            <div class="search">
                                <input class="search-input" type="text" placeholder="Search..">
                                <select class="search-category" name="" id="">
                                    <option value="0">Categories</option>
                                    <option value="2">Nama</option>
                                    <option value="3">Nama</option>
                                    <option value="4">Nama</option>
                                    <option value="5">Nama</option>
                                    <option value="6">Nama</option>
                                </select>
                                <button class="search-button"><i class="fa-solid fa-magnifying-glass"></i>    Search</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-sm-4"></div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\OpenServer\domains\alp.ge\resources\views/layouts/web/navbar.blade.php ENDPATH**/ ?>