<div class="container">
    <div class="row">

        <div class="col-sm-9 main-slider-container">
            <div class="swiper main-slider animate__animated animate__fadeInDown animate__faster">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="mslider-desc animate__animated animate__fadeInLeft">
                            <div class="mslide-desc-status">
                                New In Stock
                            </div>
                            <div class="mslide-desc-subtitle">
                                Sub Title
                            </div>
                            <div class="mslide-desc-title">
                                Title can be cool
                            </div>
                            <div class="mslide-desc-btn">
                                <button>Shop Now</button>
                            </div>
                        </div>
                        <img src="<?php echo e(asset('slider_temp/1.jpg')); ?>" alt="">
                    </div>
                  <div class="swiper-slide">
                    <div class="mslider-desc animate__animated animate__fadeInLeft">
                        <div class="mslide-desc-status">
                            New In Stock
                        </div>
                        <div class="mslide-desc-subtitle">
                            Sub Title
                        </div>
                        <div class="mslide-desc-title">
                            Title can be cool
                        </div>
                        <div class="mslide-desc-btn">
                            <button>Shop Now</button>
                        </div>
                    </div>
                      <img src="<?php echo e(asset('slider_temp/2.jpg')); ?>" alt="">
                    </div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </div>
        <div class="col-sm-3 sbannner-container">
            <div class="sbannner-right animate__animated animate__fadeInRight animate__faster">
                <div class="sbanner-item">
                    <img src="<?php echo e(asset('slider_temp/1.jpg')); ?>" alt="">
                </div>
                <div class="sbanner-item">
                    <img src="<?php echo e(asset('slider_temp/2.jpg')); ?>" alt="">
                </div>
                <div class="sbanner-item">
                    <img src="<?php echo e(asset('slider_temp/1.jpg')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\OpenServer\domains\alp.ge\resources\views/layouts/web/slider.blade.php ENDPATH**/ ?>