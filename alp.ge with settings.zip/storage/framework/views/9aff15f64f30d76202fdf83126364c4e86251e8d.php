<div class="topmenu top-menu-container">
    <div class="container">
        <div class="row">
            <div class="col-sm-3">
                <div class="cat-menu">
                    <div class="cat-menu-title">
                        <i class="fa-solid fa-bars"></i>
                        <span>Categories</span>
                    </div>
                    <div class="cat-menu-list">
                        <ul>
                            <li><a href=""><i class="fa-solid fa-arrow-right-long"></i><span>dasdasdadsad</span></a></li>
                            <li><a href=""><i class="fa-solid fa-arrow-right-long"></i><span>dasdasdadsad</span></a></li>
                            <li><a href=""><i class="fa-solid fa-arrow-right-long"></i><span>dasdasdadsad</span></a></li>
                            <li><a href=""><i class="fa-solid fa-arrow-right-long"></i><span>dasdasdadsad</span></a></li>
                            <li><a href=""><i class="fa-solid fa-arrow-right-long"></i><span>dasdasdadsad</span></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="main-nav">
                    <ul class="main-nav-list">
                        <li class="main-nav-item"><a href="" class="main-nav-link">Main</a></li>
                        <li class="main-nav-item"><a href="" class="main-nav-link">Blog</a></li>
                        <li class="main-nav-item"><a href="" class="main-nav-link">Post</a></li>
                        <li class="main-nav-item">
                            <a href="" class="main-nav-link">Dropdown <i class="fa-solid fa-angle-down"></i></a>
                            <ul class="main-drop">
                                <li class="main-drop-item"><a href="" class="main-drop-link">Drop 1</a></li>
                                <li class="main-drop-item"><a href="" class="main-drop-link">Drop 2</a></li>
                                <li class="main-drop-item"><a href="" class="main-drop-link">Drop 3</a></li>
                                <li class="main-drop-item"><a href="" class="main-drop-link">Drop 4</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="contact-us-btn">
                    <button>Contact Us</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\OpenServer\domains\alp.ge\resources\views/layouts/web/topmenu.blade.php ENDPATH**/ ?>