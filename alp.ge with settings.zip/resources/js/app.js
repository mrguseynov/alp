require('./bootstrap');
window.Swiper = require('swiper');
require('./swiper-index-photos');
